// C++ program to display "Hello World"

// Header file for input output functions
#include <iostream>
using namespace std;

// Main() function: where the execution of
// program begins
int main()
{
	// Prints hello world
	cout << "Hello World test"<<endl;

	return 0;
}
