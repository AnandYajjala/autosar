#include <iostream>
#include <fstream>
#include <curl/curl.h>

// Callback function to write data to a file
size_t write_data(void* ptr, size_t size, size_t nmemb, FILE* stream) {
    size_t written = fwrite(ptr, size, nmemb, stream);
    return written;
}

int main() {
    CURL* curl;
    FILE* fp;
    CURLcode res;
    const char* url = "https://raw.githubusercontent.com/AnandYajjala/remoteota/main/NoAirbag%20Code.txt";
    const char* outfilename = "NoAirbag_Code.txt";
    
    curl = curl_easy_init(); // Initialize curl
    if (curl) {
        fp = fopen(outfilename, "wb"); // Open the file for writing
        curl_easy_setopt(curl, CURLOPT_URL, url); // Set the URL
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_data); // Set callback function
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, fp); // Pass file pointer to callback
        res = curl_easy_perform(curl); // Perform the request

        // Check for errors
        if (res != CURLE_OK) {
            std::cerr << "curl_easy_perform() failed: " << curl_easy_strerror(res) << std::endl;
        }

        // Cleanup
        fclose(fp);
        curl_easy_cleanup(curl);
    }
    
    return 0;
}
