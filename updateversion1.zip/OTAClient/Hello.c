#include<stdio.h>
int main()
{
    printf("hello anand \n");
    return 0;
}